SYSTEME_API_KEY = 'ykjgqwc9l3sznnrvgoauxqpuuogy48tn4zb93xjc95ikuf8sp3x30t8uadb4n92j'
SYSTEME_CONTACTS_URL = "https://api.systeme.io/api/contacts"
SYSTEME_TAGS_URL = "https://api.systeme.io/api/tags"


